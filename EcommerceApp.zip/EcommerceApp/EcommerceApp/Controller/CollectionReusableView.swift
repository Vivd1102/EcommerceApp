//
//  CollectionReusableView.swift
//  EcommerceApp
//
//  Created by vivek bajirao deshmukh on 28/06/20.
//  Copyright © 2020 vivek bajirao deshmukh. All rights reserved.
//

import UIKit

class CollectionReusableView: UICollectionReusableView {
        
    @IBOutlet weak var lblHeader: UILabel!
}
