//
//  Constant.swift
//  iOSArchitecture
//
//  Created by Amit Shukla on 05/07/18.
//  Copyright © 2018 smartData. All rights reserved.
//

import Foundation

enum Config {
    
    // Copy base url here
    static let baseUrl = "https://stark-spire-93433.herokuapp.com/json"

}
