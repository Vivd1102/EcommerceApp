//
//  ViewController.swift
//  EcommerceApp
//
//  Created by vivek bajirao deshmukh on 27/06/20.
//  Copyright © 2020 vivek bajirao deshmukh. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout {
    
    @IBOutlet weak var collectionView: UICollectionView!
    private let spacing:CGFloat = 30.0
    var arrayproducts:[Products]? = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.initalization()
        // Do any additional setup after loading the view.
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(true)
        self.apiCall()
    }
    
    func initalization(){
        self.title = "Categories"
        self.collectionView.delegate = self
        self.collectionView.dataSource = self
        let layout = UICollectionViewFlowLayout()
        layout.sectionInset = UIEdgeInsets(top: spacing, left: spacing, bottom: spacing, right: spacing)
        layout.minimumLineSpacing = spacing
        layout.minimumInteritemSpacing = spacing
        self.collectionView?.collectionViewLayout = layout
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return AppInstance.shared.categories?.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CustomCollectionVCell", for: indexPath as IndexPath) as! CustomCollectionVCell
        if let basevalue = AppInstance.shared.categories?[indexPath.row] {
            cell.lblproducts.text = basevalue.name
        }
        return cell
    }
    
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
       let numberOfItemsPerRow:CGFloat = 2
       let spacingBetweenCells:CGFloat = 30
       
       let totalSpacing = (2 * self.spacing) + ((numberOfItemsPerRow - 1) * spacingBetweenCells) //Amount of total spacing in a row
       
       if let collection = self.collectionView{
           let width = (collection.bounds.width - totalSpacing)/numberOfItemsPerRow
           return CGSize(width: width, height: width)
       }else{
           return CGSize(width: 0, height: 0)
       }
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        print(indexPath.row)
        if let basevalue = AppInstance.shared.categories?[indexPath.row]{
            if let products: [Products] = basevalue.products{
                self.arrayproducts = products
                AppInstance.shared.product = basevalue.products
                self.movetoLoginscreen(array: self.arrayproducts ?? [])
            }
        }
    }
    
    
    func apiCall(){
        let service = UserService()
        service.getFactslist( target: self, complition: { (response) in
            if let resultresponse = response{
                AppInstance.shared.categories = resultresponse as? [Categories]
                print(AppInstance.shared.ranking ?? [])
                print(resultresponse)
            }
            DispatchQueue.main.async {
                self.collectionView.reloadData()
            }
        })
    }
    
    func movetoLoginscreen(array:[Products]){
        let mainStoryboard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let nextview = mainStoryboard.instantiateViewController(withIdentifier: "ProductsVC") as! ProductsVC
        nextview.arrayitems = array
        self.navigationController?.pushViewController(nextview, animated: true)
    }
    
    
    
}

