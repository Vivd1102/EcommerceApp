//
//  CustomCollectionVCell.swift
//  EcommerceApp
//
//  Created by vivek bajirao deshmukh on 27/06/20.
//  Copyright © 2020 vivek bajirao deshmukh. All rights reserved.
//

import UIKit

class CustomCollectionVCell: UICollectionViewCell {
    
    @IBOutlet weak var lblproducts: UILabel!
}
