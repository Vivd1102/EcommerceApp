//
//  ProductsVC.swift
//  EcommerceApp
//
//  Created by vivek bajirao deshmukh on 28/06/20.
//  Copyright © 2020 vivek bajirao deshmukh. All rights reserved.
//

import UIKit

class ProductsVC: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout {
    
    @IBOutlet weak var collectionview: UICollectionView!
    var arrayitems:[Products]? = []
    private let spacing:CGFloat = 30.0

    @IBOutlet weak var flowlayout: CollectionReusableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.initalization()
        print(arrayitems ?? [],AppInstance.shared.product ?? [])
    }
    
    
    func initalization(){
            self.title = "Products"
            self.collectionview.delegate = self
            self.collectionview.dataSource = self
            let layout = UICollectionViewFlowLayout()
            layout.sectionInset = UIEdgeInsets(top: spacing, left: spacing, bottom: spacing, right: spacing)
            layout.minimumLineSpacing = spacing
            layout.minimumInteritemSpacing = spacing
            self.collectionview?.collectionViewLayout = layout
        

        }
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return AppInstance.shared.ranking?.count ?? 0
    }
        
        func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
            return AppInstance.shared.product?.count ?? 0
        }
        
        func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CustomCollectionVCell", for: indexPath as IndexPath) as! CustomCollectionVCell
//            let arrayproducts = AppInstance.shared.product
            if let basevalue = AppInstance.shared.product?[indexPath.row] {
                cell.lblproducts.text = basevalue.name
            }
            return cell
        }

        
        func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
           let numberOfItemsPerRow:CGFloat = 2
           let spacingBetweenCells:CGFloat = 30
           
           let totalSpacing = (2 * self.spacing) + ((numberOfItemsPerRow - 1) * spacingBetweenCells) //Amount of total spacing in a row
           if let collection = self.collectionview{
               let width = (collection.bounds.width - totalSpacing)/numberOfItemsPerRow
               return CGSize(width: width, height: width)
           }else{
               return CGSize(width: 0, height: 0)
           }
//            flowLayout.headerReferenceSize = CGSizeMake(self.collectionView.frame.size.width, 100.f);
        }
    
//    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
//        if kind == UICollectionView.elementKindSectionHeader {
//            let view = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: "CollectionReusableView", for: indexPath) as! CollectionReusableView
//            // do any programmatic customization, if any, here
//            if let headertitle = AppInstance.shared.ranking?[indexPath.section]{
//                view.lblHeader.text = headertitle.ranking
//
//            }
//            return view
//        }
//        fatalError("Unexpected kind")
//    }
    func collectionView(_ collectionView: UICollectionView,
                                 viewForSupplementaryElementOfKind kind: String,
                                 at indexPath: IndexPath) -> UICollectionReusableView {
        // 1
        switch kind {
        // 2
        case UICollectionView.elementKindSectionHeader:
            // 3
            guard
                let headerView = collectionView.dequeueReusableSupplementaryView(
                    ofKind: kind,
                    withReuseIdentifier: "\("CollectionReusableView")",
                    for: indexPath) as? CollectionReusableView
                else {
                    fatalError("Invalid view type")
            }
            if let headertitle = AppInstance.shared.ranking?[indexPath.section]{
                headerView.lblHeader.text = headertitle.ranking
            }
            return headerView
            
        default:
            // 4
            assert(false, "Invalid element type")
        }
    }
    
    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        referenceSizeForHeaderInSection section: Int) -> CGSize {

        return CGSize(width: collectionView.bounds.width, height: 50)
    }
    
 

}
