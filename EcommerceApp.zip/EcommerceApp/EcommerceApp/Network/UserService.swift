//
//  LoginAPIManager.swift
//  iOSArchitecture
//
//  Created by Amit on 23/02/18.
//  Copyright © 2018 smartData. All rights reserved.
//

import Foundation
import UIKit


public class UserService:APIService {
    
    // #show and hide loader in this class depending on your needs.
    // #you can make service class according to module
    // #show errors in this class, if you have any need where you want to show in controller class, then just by-pass error method.
    
    
        func getFactslist(target:UIViewController? = nil,complition:@escaping (Any?) -> Void){
        //        target?.showLoader()
            super.startService(with:.GET, parameters: nil,files: []) { (result) in
                    DispatchQueue.main.async {
                        switch result {
                        case .Success(let response):
                            // #parse response here
                            
                            if let rankdata = ( response as? Dictionary<String,Any>)?["rankings"] as? Array<Dictionary<String,Any>>{
                                print(rankdata)
                                let rankings = Rankings.modelsFromDictionaryArray(array: rankdata as NSArray)
                                AppInstance.shared.ranking = rankings
                            }
                            
                            if let data = ( response as? Dictionary<String,Any>)?["categories"] as? Array<Dictionary<String,Any>>{
                                let eventsData = Categories.modelsFromDictionaryArray(array: data as NSArray)
                                complition(eventsData)
                            } else {
                                complition(nil)

                            }
                            
//                             if let data = ( response as? Dictionary<String,Any>)?["ranking"] as? Array<Dictionary<String,Any>>{
//                                let newsdata = Base.modelsFromDictionaryArray(array: data as NSArray)
//                                // let assessment = AssessmentModel(dictionary: data)
//                                complition(newsdata)
//                             } else {
//                                complition(nil)
//
//                            }
                            
                        case .Error(let _):
                            // #display error message here
                            complition(nil)
                        }
                    }
                }
        }

    
    
}

